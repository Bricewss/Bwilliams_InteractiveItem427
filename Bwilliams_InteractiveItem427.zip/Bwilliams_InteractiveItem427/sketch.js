let images = [];
let currentIndex = 0;
let radius = 24;

function preload() {
  images[0] = loadImage('INTERACTIVEIMGS/FACE1.jpg');
  images[1] = loadImage('INTERACTIVEIMGS/FACE2.jpg');
  images[2] = loadImage('INTERACTIVEIMGS/FACE3.jpg');
  sound = createAudio('MP4 SOUND/cascade-d0d-main-version-30737-02-33.mp3');
}

function setup() {
  createCanvas(800, 800);
  ellipseMode(RADIUS);
}

function mousePressed() {
  currentIndex = (currentIndex + 1) % images.length;
  sound.play();
}

function draw() {
  image(images[currentIndex], 0, 0, width, height);



  



  let leftEyeX = 450;
  let leftEyeY = 310;
  noStroke();
  fill(0, 0, 0, 0);
  ellipse(leftEyeX, leftEyeY, 30);

  let distanceXLeft = mouseX - leftEyeX;
  let distanceYLeft = mouseY - leftEyeY;
  let distanceLeft = sqrt(distanceXLeft * distanceXLeft + distanceYLeft * distanceYLeft);
  let maxDistanceLeft = 30 - 10;

  let smallCircleXLeft = mouseX;
  let smallCircleYLeft = mouseY;

  if (distanceLeft > maxDistanceLeft) {
    let ratioLeft = maxDistanceLeft / distanceLeft; 
    smallCircleXLeft = leftEyeX + distanceXLeft * ratioLeft;
    smallCircleYLeft = leftEyeY + distanceYLeft * ratioLeft;
  }

  fill(255);
  ellipse(smallCircleXLeft, smallCircleYLeft, 10);







  let rightEyeX = 582; 
  let rightEyeY = 330; 
  noStroke();
  fill(0, 0, 0, 0);
  ellipse(rightEyeX, rightEyeY, 30);

  let distanceXRight = mouseX - rightEyeX;
  let distanceYRight = mouseY - rightEyeY;
  let distanceRight = sqrt(distanceXRight * distanceXRight + distanceYRight * distanceYRight);
  let maxDistanceRight = 30 - 10;

  let smallCircleXRight = mouseX;
  let smallCircleYRight = mouseY;

  if (distanceRight > maxDistanceRight) {
    let ratioRight = maxDistanceRight / distanceRight;
    smallCircleXRight = rightEyeX + distanceXRight * ratioRight;
    smallCircleYRight = rightEyeY + distanceYRight * ratioRight;
  }

  fill(255);
  ellipse(smallCircleXRight, smallCircleYRight, 10);
}
